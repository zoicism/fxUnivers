<!DOCTYPE html>
<html>
  <head>
    <title>Wait</title>
  </head>
  <body>
    <h3>Hi there!</h3>
    <p>Your CV has been submitted and will be reviewd by us.</p>
    <p>We will reach you as soon as the results come in.</p>
    <p>Thanks for your patience,<br><i>fxTeam</i></p>
  </body>
</html>
