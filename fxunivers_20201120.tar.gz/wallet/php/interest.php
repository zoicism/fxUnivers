<?php

function interest(r,m) {
    $interest=ceil(r*m);
}

?>