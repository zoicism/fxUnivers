# fxUnivers
fxUnivers is a financial multiplatform website where users can buy "fxStars" and use them to trade for services and productions created by us or other users. We get our small share in each transaction of these fxStars through various usages.

## fxStar
fxUnivers is based on fxStars; these are chips that we sell to the users so that they can use other parts of the website with them. There are different ways to buy, ear, or spend fxStars. Users can request fxStars from their friends which is followed by the transaction taking place if it's accepted. Users can also send fxStars to their friends and the transaction takes place immediately. The fxStars and the transactions are securely encrypted.

## fxUniversity
fxUniversity is the university platform where users can take up courses and live courses by spending fxStars, or gain fxStars by creating courses and selling them to the rest of the users. 0.1 of the transactions here, whether the user is making them as a student or an instructor, goes to us.

## fxPartner
Users can make money by bringing on a partnership to us. It's really simple to use and it only needs connections; a partner sends invitation links to people who are not on fxUnivers, and if they register as a user, the partner gets half of the share we get from that new user for 90 days.

## fxUniverse
Trading Platform (coming soon)

## fxSonet
Social Network Platform (coming soon)
